const e={hello:{t:0,b:{t:2,i:[{t:3}],s:"Hello world"}}};export{e as default};
